# Jumat Berkah – Masjid Istiqamah

Android WebView app for the supplied Jumat Berkah V17 web app.

## App details
- Application ID: `com.masjidistiqamah.jumatberkah`
- Version: 1.0 (debug APK)
- Min Android: 6.0 (API 23)
- Compile SDK: 35; target SDK: 34
- Java: Temurin 17; Gradle: 8.7
- Splash screen: supplied Masaji Den logo for 3 seconds
- Status bar and Android navigation bar remain visible (not fullscreen)
- Backup uses Android's Save As picker; Restore uses Android's file picker.

## Build APK using GitHub Actions
1. Upload the contents of this folder to a new GitHub repository (branch `main`).
2. Open the repository's **Actions** tab.
3. Run **Build Jumat Berkah APK** (or push a commit).
4. Open the completed workflow run and download the `Jumat-Berkah-APK` artifact.
5. Extract the artifact ZIP to get `app-debug.apk`.

This debug APK is suitable for testing and installation. For future install-over-update compatibility, keep the same application ID and signing key. A release keystore has not been created in this project.

## Notes
- The app stores its data in WebView local storage on the device. Uninstalling the app or clearing its app storage may erase local data; use Backup regularly.
- The web content and supplied logo are bundled locally. Internet access is not required for normal use.


## Private release signing (important)
This project is configured to build a signed release APK using GitHub Actions repository secrets.
Do NOT commit or upload `release-key.jks` into the repository.

Add these repository secrets under Settings → Secrets and variables → Actions:
- `ANDROID_KEYSTORE_BASE64`: contents of `keystore-base64.txt` from the separate private signing package
- `ANDROID_KEYSTORE_PASSWORD`: keystore password from `signing-details.txt`
- `ANDROID_KEY_ALIAS`: `jumatberkah-release`
- `ANDROID_KEY_PASSWORD`: key password from `signing-details.txt`

Keep the private signing package and at least one offline backup in a safe place. Every future update must use this exact keystore, alias, and application ID `com.masjidistiqamah.jumatberkah`. If the keystore or password is lost, Android will not allow an update to replace an installation signed with this key.


## v9 – Tanggal pada Ucapan Terima Kasih
Ucapan terima kasih per donatur menampilkan hari dan tanggal kegiatan berdasarkan tanggal Jumat yang sedang dipilih pada aplikasi.
